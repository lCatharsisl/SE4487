class Config:
    SQLALCHEMY_DATABASE_URI = 'mysql+pymysql://root:123456789@localhost/personal_contact_manager'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
