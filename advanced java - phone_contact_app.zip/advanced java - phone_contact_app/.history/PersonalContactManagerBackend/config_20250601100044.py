class Config:
    SQLALCHEMY_DATABASE_URI = 'mysql+pymysql://root:Radyoloji1968@localhost/personal_contact_manager'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
