pip install -r requirements.txt

pip freeze > requirements.txt